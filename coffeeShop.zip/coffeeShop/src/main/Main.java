package main;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import model.Coffee;
import model.Drink;
import model.OrangeJuice;
public class Main {
	public static void main(String[] args) {
		boolean isOpen = true;
		List<Drink> orderList = new ArrayList<Drink>();
		while(isOpen) {
			//説明を表示
			System.out.println("番号を選択してください");
			System.out.println("1:オーダー 2:精算 3:終了");
			//入力制御
			try {
				int choice = new Scanner(System.in).nextInt();
				//System.out.println("あなたが選択したのは"+choice+"です");
				//制御
				if(choice < 1 || choice > 3) {
					System.out.println("正しい入力がされていません");
					continue;
				}
				//終了
				if(choice == 3) {
					System.out.println("終了します");
					isOpen = false;
				}
				//オーダー処理
				if(choice == 1) {
					System.out.println("オーダーが選択されました。");
					System.out.println("メニューを選択してください");
					System.out.println("1:ホットコーヒー 2:アイスコーヒー 3:オレンジジュース");
					try {
						int choiceOfMenu = new Scanner(System.in).nextInt();
						if(choiceOfMenu < 1 || choiceOfMenu > 3) {
							System.out.println("正しい入力がされていません");
							continue;
						}
						Drink item;
						switch(choiceOfMenu) {
							case 1:
								item = new Coffee(true);
								break;
							case 2:
								item = new Coffee(false);
								break;
							case 3:
								item = new OrangeJuice();
								break;
							default:
								System.out.println("正しい入力がされていません");
								continue;
						}
						item.show();
						orderList.add(item);
					}catch(InputMismatchException e) {
						System.out.println("数字以外が選択されています");
						System.out.println("メニューにもどります");
						continue;
					}
				}
				//精算
				if(choice == 2) {
					System.out.println("精算が選択されました。");
					int totalPrice = 0;
					for(Drink d : orderList) {
						totalPrice += d.getPrice();
					}
					System.out.println("代金は"+totalPrice+"円です");
				}
				
			}catch(InputMismatchException e) {
				System.out.println("数字以外が選択されています");
				System.out.println("メニューにもどります");
				continue;
			}
		}

	}

}
