package main;

import java.util.Scanner;

public class Start {

	public static void main(String[] args) {
		boolean isOpen = true;
		while(isOpen) {
			//説明を表示
			System.out.println("番号を選択してください");
			System.out.println("1:オーダー 2:精算 3:終了");
			
			//入力値(整数)を取得
			int choice = new Scanner(System.in).nextInt();
			System.out.println("あなたが選択したのは"+choice+"です");
			//終了
			isOpen = false;
			
		}
	}

}
