/**
 * 
 */
/**
 * @author takuji
 *
 */
module coffeeShop {
}