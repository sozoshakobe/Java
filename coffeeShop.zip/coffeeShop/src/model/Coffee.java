package model;

public class Coffee extends Drink{
	private boolean isHot;
	
	public Coffee(boolean isHot) {
		super("コーヒー",500);
		this.isHot = isHot;
	}

	public void show() {
		String hotOrCold = "ホット";
		if(!isHot) {
			hotOrCold = "アイス";
		}
		System.out.println("ご注文は"+this.getName()+"、"+hotOrCold+"で承りました");
	}
}
