package model;

public abstract class Drink {
	private String name;
	private int price;
	
	public Drink(String name,int price) {
		this.name = name;
		this.price = price;
	}
	
	public abstract void show();

	public String getName() {
		return name;
	}

	public int getPrice() {
		return price;
	}
}
