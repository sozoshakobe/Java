package model;

public class OrangeJuice extends Drink {
	public OrangeJuice() {
		super("オレンジジュース",400);
	}
	public void show() {
		System.out.println("ご注文は"+this.getName()+"で承りました");
	}
}
